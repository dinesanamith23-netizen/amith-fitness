# Privacy Policy – AMITH FIT (90 Day Transformation)

**Effective Date:** November 25, 2026  
**App Name:** AMITH FIT – 90 Day Transformation  
**Package / Bundle ID:** `com.amithfit.transformation`

## 1. Data Storage & Processing
- AMITH FIT stores fitness profiles, workout completions, nutrition logs, measurements, and optional progress photos locally on your device (`localStorage` in web/PWA mode).
- No external paid AI API or cloud workout server is required for core coaching, workout tracking, or nutrition tracking.

## 2. Backup & Export
- You can export your local data as a JSON backup file at any time from the **Profile** tab and restore it later. Clearing browser or app storage removes local data unless backed up.

## 3. Health & Medical Disclaimer
- Fitness plans, calorie/protein estimates, posture exercises, and height/posture information are educational and do not replace medical advice. Stop exercising and seek medical care if you experience chest pain, severe pain, dizziness, or unusual breathlessness.
