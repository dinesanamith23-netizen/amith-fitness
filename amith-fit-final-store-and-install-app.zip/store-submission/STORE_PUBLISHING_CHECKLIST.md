# Google Play Store & Apple App Store Publishing Checklist

## 1. Ready-to-Use PWA (`www/`)
- Host `www/` over **HTTPS** (GitHub Pages, Netlify, Vercel, or Cloudflare Pages).
- **iPhone (Safari):** Open the `https://` URL -> **Share** -> **Add to Home Screen**.
- **Android (Chrome):** Open the `https://` URL -> **Install App** (or Menu `⋮` -> **Install app** / **Add to Home screen**).

## 2. Google Play Store (.aab)
1. In `capacitor-app/`, run `npm install` and `npx cap sync android` (or open `capacitor-app/android` in Android Studio).
2. Sign your release build with a keystore and generate an Android App Bundle (`.aab`) in Android Studio.
3. Upload the `.aab`, app icons (`512x512`), screenshots, health/fitness declarations, and privacy policy to Google Play Console (requires a Google Play Developer account).

## 3. Apple App Store (iOS via Mac + Xcode)
1. On a Mac with Xcode installed, run `npm install` and `npx cap sync ios` inside `capacitor-app/`.
2. Open the iOS project in Xcode, set your Apple Developer Team & signing certificate, archive the build, and upload to App Store Connect (requires an Apple Developer Program membership).
