import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.amithfit.transformation',
  appName: 'AMITH FIT',
  webDir: 'www',
  server: {
    androidScheme: 'https'
  }
};

export default config;
